<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Services\Integrations\N8n\N8nClient;
use App\Models\MarketingCampaignPost;
use Illuminate\Support\Facades\Storage;
use Throwable;

class SendMarketingCampaignPostToN8nJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3;

    public function __construct(
        public MarketingCampaignPost $post,
        public array $payload,
        public ?string $temp_path = null,
        public bool $savedToClient = false
    ) {}

    public function handle(N8nClient $client): void
    {
        $client->submitMarketingCampaignPost($this->payload);

        $this->post->update([
            'status' => \App\Enums\Social\MarketingCampaignPostStatus::SubmittedToN8n->value,
            'submitted_to_n8n_at' => now(),
        ]);

    }

    public function failed(Throwable $e): void
    {
        $updates = [
            'n8n_error' => substr($e->getMessage(), 0, 255)
        ];

        if (in_array($this->post->status->value, [
            \App\Enums\Social\MarketingCampaignPostStatus::PendingN8n->value,
            \App\Enums\Social\MarketingCampaignPostStatus::SubmittedToN8n->value
        ])) {
            $updates['status'] = $this->post->n8n_previous_status?->value ?? \App\Enums\Social\MarketingCampaignPostStatus::Draft->value;
        }

        $this->post->update($updates);

        if ($this->shouldDeleteTempFile()) {
            Storage::disk('public')->delete($this->temp_path);
            
            $n8nInternalContext = $this->post->n8n_internal_context ?? [];
            if (isset($n8nInternalContext['_internal_temp_logo_path'])) {
                unset($n8nInternalContext['_internal_temp_logo_path']);
                $this->post->update(['n8n_internal_context' => $n8nInternalContext]);
            }
        }
    }

    private function shouldDeleteTempFile(): bool
    {
        return $this->temp_path && !$this->savedToClient;
    }
}
